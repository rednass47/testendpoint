# Description

This resource can be used to manage the policies under the Security Options node
in local security policies.
