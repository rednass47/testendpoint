# Description

This resource can be used to manage user rights assignment that are defined
in an INF file.
