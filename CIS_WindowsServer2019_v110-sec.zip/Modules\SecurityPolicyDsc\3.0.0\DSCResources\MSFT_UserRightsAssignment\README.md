# Description

This resource can be used to manage user rights assignment in local security policies.
