# Description

This resource can be used to manage the policies under the Account Policy node
in local security policies.
